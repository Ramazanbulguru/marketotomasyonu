﻿namespace Market_Otomasyonu
{
    partial class YeniUrunGirisEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonGeri = new System.Windows.Forms.Button();
            this.buttonYeniUrunEkle = new System.Windows.Forms.Button();
            this.textBoxUrunAdeti = new System.Windows.Forms.TextBox();
            this.textBoxUrunFiyati = new System.Windows.Forms.TextBox();
            this.textBoxUrunAdi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // buttonGeri
            // 
            this.buttonGeri.Location = new System.Drawing.Point(12, 12);
            this.buttonGeri.Name = "buttonGeri";
            this.buttonGeri.Size = new System.Drawing.Size(75, 23);
            this.buttonGeri.TabIndex = 17;
            this.buttonGeri.Text = "GERİ";
            this.buttonGeri.UseVisualStyleBackColor = true;
            this.buttonGeri.Click += new System.EventHandler(this.buttonGeri_Click);
            // 
            // buttonYeniUrunEkle
            // 
            this.buttonYeniUrunEkle.Location = new System.Drawing.Point(348, 357);
            this.buttonYeniUrunEkle.Name = "buttonYeniUrunEkle";
            this.buttonYeniUrunEkle.Size = new System.Drawing.Size(123, 23);
            this.buttonYeniUrunEkle.TabIndex = 16;
            this.buttonYeniUrunEkle.Text = "YENİ ÜRÜNÜ EKLE";
            this.buttonYeniUrunEkle.UseVisualStyleBackColor = true;
            this.buttonYeniUrunEkle.Click += new System.EventHandler(this.buttonYeniUrunEkle_Click);
            // 
            // textBoxUrunAdeti
            // 
            this.textBoxUrunAdeti.Location = new System.Drawing.Point(442, 285);
            this.textBoxUrunAdeti.Name = "textBoxUrunAdeti";
            this.textBoxUrunAdeti.Size = new System.Drawing.Size(150, 20);
            this.textBoxUrunAdeti.TabIndex = 15;
            // 
            // textBoxUrunFiyati
            // 
            this.textBoxUrunFiyati.Location = new System.Drawing.Point(442, 229);
            this.textBoxUrunFiyati.Name = "textBoxUrunFiyati";
            this.textBoxUrunFiyati.Size = new System.Drawing.Size(150, 20);
            this.textBoxUrunFiyati.TabIndex = 14;
            // 
            // textBoxUrunAdi
            // 
            this.textBoxUrunAdi.Location = new System.Drawing.Point(442, 178);
            this.textBoxUrunAdi.Name = "textBoxUrunAdi";
            this.textBoxUrunAdi.Size = new System.Drawing.Size(150, 20);
            this.textBoxUrunAdi.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(260, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "ÜRÜN ADETİ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(260, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "ÜRÜN FİYATI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(260, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "ÜRÜN ADI";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(324, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "YENİ ÜRÜN GİRME EKRANI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(263, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "ÜRÜN KATEGORİSİ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Lütfen Kategori Seçiniz...",
            "Manav",
            "Icecek",
            "Temizlik"});
            this.comboBox1.Location = new System.Drawing.Point(442, 140);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(150, 21);
            this.comboBox1.TabIndex = 19;
            // 
            // YeniUrunGirisEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Market_Otomasyonu.Properties.Resources.resized_17d09_c876mm;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buttonGeri);
            this.Controls.Add(this.buttonYeniUrunEkle);
            this.Controls.Add(this.textBoxUrunAdeti);
            this.Controls.Add(this.textBoxUrunFiyati);
            this.Controls.Add(this.textBoxUrunAdi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "YeniUrunGirisEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yeni Ürün Giriş";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonGeri;
        private System.Windows.Forms.Button buttonYeniUrunEkle;
        private System.Windows.Forms.TextBox textBoxUrunAdeti;
        private System.Windows.Forms.TextBox textBoxUrunFiyati;
        private System.Windows.Forms.TextBox textBoxUrunAdi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}