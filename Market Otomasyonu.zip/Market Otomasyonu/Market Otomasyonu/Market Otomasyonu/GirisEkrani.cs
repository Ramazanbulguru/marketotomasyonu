﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class GirisEkrani : Form
    {
        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");

        public GirisEkrani()
        {
            InitializeComponent();
        }

        private void KbuttonKayıtOl_Click(object sender, EventArgs e)
        {
            KayitEkrani ke = new KayitEkrani();
            ke.Show();
            this.Hide();
        }

        private void KbuttonGirisYap_Click(object sender, EventArgs e)
        {
            string sorgu = "Select * from Kullanicilar Where KullaniciAdi='" + KtextBoxKAdi.Text.Trim() + "' and Sifre = '" + KtextBoxSifre.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                AnaSayfaEkrani ase = new AnaSayfaEkrani();
                ase.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı Adınızı veya Şifrenizi Hatalı Girdiniz!!!");
            }
        }
    }
}
