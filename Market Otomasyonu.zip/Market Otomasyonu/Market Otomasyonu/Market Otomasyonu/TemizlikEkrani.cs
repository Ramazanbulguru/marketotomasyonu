﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class TemizlikEkrani : Form
    {

        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");
        int ID;
        public TemizlikEkrani()
        {
            InitializeComponent();
            TemizlikListeleme();
        }

        private void buttonGeri_Click(object sender, EventArgs e)
        {
            AnaSayfaEkrani ase = new AnaSayfaEkrani();
            ase.Show();
            this.Close();
        }

        void TemizlikListeleme()
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "Select * from Temizlik";
                SqlDataAdapter dAdapter = new SqlDataAdapter(command);
                DataSet dSet = new DataSet();
                dAdapter.Fill(dSet, "Temizlik");
                dataGridView1.DataSource = dSet.Tables["Temizlik"];
                baglan.Close();
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBoxUrunAdi.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxFiyat.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxStok.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
        void TextBoxTemizleme()
        {
            ID = 0;
            textBoxUrunAdi.Text = "";
            textBoxFiyat.Text = "";
            textBoxStok.Text = "";
        }
        private void buttonEkle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "INSERT INTO dbo.Temizlik(UrunAdi,Fiyat,Stok) VALUES ('" + textBoxUrunAdi.Text.ToUpper() + "','" + textBoxFiyat.Text + "','" + textBoxStok.Text + "')";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                TemizlikListeleme();
                MessageBox.Show("TEMİZLİK ÜRÜNÜ EKLENDİ");
            }
        }

        private void buttonGuncelle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = " UPDATE Temizlik SET UrunAdi='" + textBoxUrunAdi.Text.ToUpper() + "',Fiyat='" + textBoxFiyat.Text + "',Stok='" + textBoxStok.Text + "' where id='" + ID + "'";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                TemizlikListeleme();
                MessageBox.Show("TEMİZLİK ÜRÜNÜ GÜNCELLENDİ");
            }
        }

        private void buttonSil_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ?", "UYARI!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (baglan.State == ConnectionState.Closed)
                {
                    baglan.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = baglan;
                    command.CommandText = "DELETE from dbo.Temizlik where id=@id";
                    command.Parameters.AddWithValue("@id", ID);
                    command.ExecuteNonQuery();
                    command.Dispose();
                    baglan.Close();
                    TextBoxTemizleme();
                    TemizlikListeleme();
                    MessageBox.Show("TEMİZLİK ÜRÜNÜ SİLİNDİ");
                }
            }
        }
    }
}
