﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class KullaniciEkrani : Form
    {

        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");
        int ID;
        public KullaniciEkrani()
        {
            InitializeComponent();
            KullanicilarListeleme();
        }

        private void buttonGeri_Click(object sender, EventArgs e)
        {
            AnaSayfaEkrani ase = new AnaSayfaEkrani();
            ase.Show();
            this.Close();
        }

        void KullanicilarListeleme()
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "Select * from Kullanicilar";
                SqlDataAdapter dAdapter = new SqlDataAdapter(command);
                DataSet dSet = new DataSet();
                dAdapter.Fill(dSet, "Kullanicilar");
                dataGridView1.DataSource = dSet.Tables["Kullanicilar"];
                baglan.Close();
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBoxKullaniciAdi.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxSifre.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
        void TextBoxTemizleme()
        {
            ID = 0;
            textBoxKullaniciAdi.Text = "";
            textBoxSifre.Text = "";
        }
        private void buttonEkle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "INSERT INTO dbo.Kullanicilar(KullaniciAdi,Sifre) VALUES ('" + textBoxKullaniciAdi.Text + "','" + textBoxSifre.Text + "')";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                KullanicilarListeleme();
                MessageBox.Show("KULLANICI EKLENDİ");
            }
        }

        private void buttonGuncelle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = " UPDATE Kullanicilar SET KullaniciAdi='" + textBoxKullaniciAdi.Text + "',Sifre='" + textBoxSifre.Text + "' where id='" + ID + "'";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                KullanicilarListeleme();
                MessageBox.Show("KULLANICI GÜNCELLENDİ");
            }
        }

        private void buttonSil_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ?", "UYARI!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (baglan.State == ConnectionState.Closed)
                {
                    baglan.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = baglan;
                    command.CommandText = "DELETE from dbo.Kullanicilar where id=@id";
                    command.Parameters.AddWithValue("@id", ID);
                    command.ExecuteNonQuery();
                    command.Dispose();
                    baglan.Close();
                    TextBoxTemizleme();
                    KullanicilarListeleme();
                    MessageBox.Show("KULLANICI SİLİNDİ");
                }
            }
        }
    }
}
