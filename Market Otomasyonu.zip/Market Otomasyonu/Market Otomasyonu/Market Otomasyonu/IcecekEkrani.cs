﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class IcecekEkrani : Form
    {

        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");
        int ID;
        public IcecekEkrani()
        {
            InitializeComponent();
            IcecekListeleme();
        }

        private void buttonGeri_Click(object sender, EventArgs e)
        {
            AnaSayfaEkrani ase = new AnaSayfaEkrani();
            ase.Show();
            this.Close();
        }

        void IcecekListeleme()
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "Select * from Icecek";
                SqlDataAdapter dAdapter = new SqlDataAdapter(command);
                DataSet dSet = new DataSet();
                dAdapter.Fill(dSet, "Icecek");
                dataGridView1.DataSource = dSet.Tables["Icecek"];
                baglan.Close();
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBoxUrunAdi.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxFiyat.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxStok.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
        void TextBoxTemizleme()
        {
            ID = 0;
            textBoxUrunAdi.Text = "";
            textBoxFiyat.Text = "";
            textBoxStok.Text = "";
        }
        private void buttonEkle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = "INSERT INTO dbo.Icecek(UrunAdi,Fiyat,Stok) VALUES ('" + textBoxUrunAdi.Text.ToUpper() + "','" + textBoxFiyat.Text + "','" + textBoxStok.Text + "')";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                IcecekListeleme();
                MessageBox.Show("İÇECEK EKLENDİ");
            }
        }

        private void buttonGuncelle_Click(object sender, EventArgs e)
        {
            if (baglan.State == ConnectionState.Closed)
            {
                baglan.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = baglan;
                command.CommandText = " UPDATE Icecek SET UrunAdi='" + textBoxUrunAdi.Text.ToUpper() + "',Fiyat='" + textBoxFiyat.Text + "',Stok='" + textBoxStok.Text + "' where id='" + ID + "'";
                command.ExecuteNonQuery();
                command.Dispose();
                baglan.Close();
                TextBoxTemizleme();
                IcecekListeleme();
                MessageBox.Show("İÇECEK GÜNCELLENDİ");
            }
        }

        private void buttonSil_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ?", "UYARI!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (baglan.State == ConnectionState.Closed)
                {
                    baglan.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = baglan;
                    command.CommandText = "DELETE from dbo.Icecek where id=@id";
                    command.Parameters.AddWithValue("@id", ID);
                    command.ExecuteNonQuery();
                    command.Dispose();
                    baglan.Close();
                    TextBoxTemizleme();
                    IcecekListeleme();
                    MessageBox.Show("İÇECEK SİLİNDİ");
                }
            }
        }

    }
}
