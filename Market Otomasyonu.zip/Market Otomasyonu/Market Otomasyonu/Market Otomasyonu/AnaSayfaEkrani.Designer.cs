﻿namespace Market_Otomasyonu
{
    partial class AnaSayfaEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonManav = new System.Windows.Forms.Button();
            this.buttonIcecek = new System.Windows.Forms.Button();
            this.buttonTemizlik = new System.Windows.Forms.Button();
            this.buttonKullanicilar = new System.Windows.Forms.Button();
            this.buttonCikisYap = new System.Windows.Forms.Button();
            this.buttonYeniGiris = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonManav
            // 
            this.buttonManav.Location = new System.Drawing.Point(121, 222);
            this.buttonManav.Name = "buttonManav";
            this.buttonManav.Size = new System.Drawing.Size(103, 86);
            this.buttonManav.TabIndex = 0;
            this.buttonManav.Text = "MANAV";
            this.buttonManav.UseVisualStyleBackColor = true;
            this.buttonManav.Click += new System.EventHandler(this.buttonManav_Click);
            // 
            // buttonIcecek
            // 
            this.buttonIcecek.Location = new System.Drawing.Point(357, 222);
            this.buttonIcecek.Name = "buttonIcecek";
            this.buttonIcecek.Size = new System.Drawing.Size(103, 86);
            this.buttonIcecek.TabIndex = 1;
            this.buttonIcecek.Text = "İÇECEK";
            this.buttonIcecek.UseVisualStyleBackColor = true;
            this.buttonIcecek.Click += new System.EventHandler(this.buttonIcecek_Click);
            // 
            // buttonTemizlik
            // 
            this.buttonTemizlik.Location = new System.Drawing.Point(579, 222);
            this.buttonTemizlik.Name = "buttonTemizlik";
            this.buttonTemizlik.Size = new System.Drawing.Size(103, 86);
            this.buttonTemizlik.TabIndex = 2;
            this.buttonTemizlik.Text = "TEMİZLİK";
            this.buttonTemizlik.UseVisualStyleBackColor = true;
            this.buttonTemizlik.Click += new System.EventHandler(this.buttonTemizlik_Click);
            // 
            // buttonKullanicilar
            // 
            this.buttonKullanicilar.Location = new System.Drawing.Point(685, 12);
            this.buttonKullanicilar.Name = "buttonKullanicilar";
            this.buttonKullanicilar.Size = new System.Drawing.Size(103, 23);
            this.buttonKullanicilar.TabIndex = 3;
            this.buttonKullanicilar.Text = "KULLANICILAR";
            this.buttonKullanicilar.UseVisualStyleBackColor = true;
            this.buttonKullanicilar.Click += new System.EventHandler(this.buttonKullanicilar_Click);
            // 
            // buttonCikisYap
            // 
            this.buttonCikisYap.Location = new System.Drawing.Point(12, 12);
            this.buttonCikisYap.Name = "buttonCikisYap";
            this.buttonCikisYap.Size = new System.Drawing.Size(103, 23);
            this.buttonCikisYap.TabIndex = 4;
            this.buttonCikisYap.Text = "ÇIKIŞ YAP";
            this.buttonCikisYap.UseVisualStyleBackColor = true;
            this.buttonCikisYap.Click += new System.EventHandler(this.buttonCikisYap_Click);
            // 
            // buttonYeniGiris
            // 
            this.buttonYeniGiris.Location = new System.Drawing.Point(333, 12);
            this.buttonYeniGiris.Name = "buttonYeniGiris";
            this.buttonYeniGiris.Size = new System.Drawing.Size(155, 47);
            this.buttonYeniGiris.TabIndex = 5;
            this.buttonYeniGiris.Text = "YENİ ÜRÜN GİRİŞ EKRANI";
            this.buttonYeniGiris.UseVisualStyleBackColor = true;
            this.buttonYeniGiris.Click += new System.EventHandler(this.buttonYeniGiris_Click);
            // 
            // AnaSayfaEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Market_Otomasyonu.Properties.Resources._5bcef741c9de3d28384b8520;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonYeniGiris);
            this.Controls.Add(this.buttonCikisYap);
            this.Controls.Add(this.buttonKullanicilar);
            this.Controls.Add(this.buttonTemizlik);
            this.Controls.Add(this.buttonIcecek);
            this.Controls.Add(this.buttonManav);
            this.Name = "AnaSayfaEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ana Sayfa";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonManav;
        private System.Windows.Forms.Button buttonIcecek;
        private System.Windows.Forms.Button buttonTemizlik;
        private System.Windows.Forms.Button buttonKullanicilar;
        private System.Windows.Forms.Button buttonCikisYap;
        private System.Windows.Forms.Button buttonYeniGiris;
    }
}