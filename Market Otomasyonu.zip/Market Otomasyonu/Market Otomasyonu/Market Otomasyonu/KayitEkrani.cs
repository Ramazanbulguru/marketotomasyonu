﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class KayitEkrani : Form
    {

        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");

        public KayitEkrani()
        {
            InitializeComponent();
        }

        private void buttonKaydol_Click(object sender, EventArgs e)
        {
            string sorgu = "SELECT * FROM Kullanicilar Where KullaniciAdi='" + textBoxAd.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                TextBoxTemizleme();
                MessageBox.Show(" BU KİŞİ DAHA ÖNCE KAYIT OLMUŞ!!! ");
            }
            else
            {
                if (textBoxSifre.Text == textBoxSifre2.Text)
                {
                    if (baglan.State == ConnectionState.Closed)
                    {
                        baglan.Open();
                        SqlCommand command = new SqlCommand();
                        command.Connection = baglan;
                        command.CommandText = "INSERT INTO dbo.Kullanicilar(KullaniciAdi,Sifre) VALUES ('" + textBoxAd.Text + "','" + textBoxSifre.Text + "')";
                        command.ExecuteNonQuery();
                        command.Dispose();
                        baglan.Close();
                        TextBoxTemizleme();
                        MessageBox.Show("KAYIT EKLENDİ");
                    }

                    GirisEkrani ge = new GirisEkrani();
                    ge.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("GİRDİĞİNİZ ŞİFRELER AYNI DEĞİL!!!");
                }
            }
        }
        void TextBoxTemizleme()
        {
            textBoxAd.Text = "";
            textBoxSifre.Text = "";
            textBoxSifre2.Text = "";
        }

        private void buttonGeri_Click(object sender, EventArgs e)
        {
            GirisEkrani ge = new GirisEkrani();
            ge.Show();
            this.Close();
        }
    }
}
