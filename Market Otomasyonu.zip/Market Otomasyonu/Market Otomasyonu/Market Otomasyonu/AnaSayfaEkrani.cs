﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class AnaSayfaEkrani : Form
    {
        public AnaSayfaEkrani()
        {
            InitializeComponent();
        }

        private void buttonManav_Click(object sender, EventArgs e)
        {
            ManavEkrani me = new ManavEkrani();
            me.Show();
            this.Close();
        }

        private void buttonIcecek_Click(object sender, EventArgs e)
        {
            IcecekEkrani ie = new IcecekEkrani();
            ie.Show();
            this.Close();
        }

        private void buttonTemizlik_Click(object sender, EventArgs e)
        {
            TemizlikEkrani te = new TemizlikEkrani();
            te.Show();
            this.Close();
        }

        private void buttonYeniGiris_Click(object sender, EventArgs e)
        {
            YeniUrunGirisEkrani yuge = new YeniUrunGirisEkrani();
            yuge.Show();
            this.Close();
        }

        private void buttonKullanicilar_Click(object sender, EventArgs e)
        {
            KullaniciEkrani ke = new KullaniciEkrani();
            ke.Show();
            this.Close();
        }

        private void buttonCikisYap_Click(object sender, EventArgs e)
        {
            GirisEkrani ge = new GirisEkrani();
            ge.Show();
            this.Close();
        }
    }
}
