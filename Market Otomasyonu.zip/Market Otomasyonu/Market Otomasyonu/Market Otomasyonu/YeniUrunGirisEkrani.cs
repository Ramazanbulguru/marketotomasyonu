﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market_Otomasyonu
{
    public partial class YeniUrunGirisEkrani : Form
    {

        SqlConnection baglan = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=MarketDB;Integrated Security=True");

        public YeniUrunGirisEkrani()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        private void buttonGeri_Click(object sender, EventArgs e)
        {
            AnaSayfaEkrani ase = new AnaSayfaEkrani();
            ase.Show();
            this.Close();
        }

        private void buttonYeniUrunEkle_Click(object sender, EventArgs e)
        {
            string sorgu = "SELECT * FROM " + comboBox1.SelectedItem + " Where Urunadi='" + textBoxUrunAdi.Text.ToUpper().Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sorgu, baglan);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                TextBoxTemizleme();
                MessageBox.Show(" BU ÜRÜNÜ DAHA ÖNCE EKLEMİŞSİNİZ!!! ");
            }
            else
            {
                if (baglan.State == ConnectionState.Closed)
                {
                    baglan.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = baglan;
                    command.CommandText = "INSERT INTO " + comboBox1.SelectedItem + "(Urunadi,Fiyat,Stok) VALUES ('" + textBoxUrunAdi.Text.ToUpper() + "','" + textBoxUrunFiyati.Text + "','" + textBoxUrunAdeti.Text + "')";
                    command.ExecuteNonQuery();
                    command.Dispose();
                    baglan.Close();
                    TextBoxTemizleme();
                    MessageBox.Show("ÜRÜN EKLENDİ");
                }
            }

        }

        void TextBoxTemizleme()
        {
            comboBox1.SelectedIndex = 0;
            textBoxUrunAdi.Text = "";
            textBoxUrunFiyati.Text = "";
            textBoxUrunAdeti.Text = "";
        }

    }
}
