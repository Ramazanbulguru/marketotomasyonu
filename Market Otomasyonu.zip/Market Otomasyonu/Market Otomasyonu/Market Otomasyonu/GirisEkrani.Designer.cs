﻿namespace Market_Otomasyonu
{
    partial class GirisEkrani
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.KbuttonGirisYap = new System.Windows.Forms.Button();
            this.KtextBoxSifre = new System.Windows.Forms.TextBox();
            this.KtextBoxKAdi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.KbuttonKayıtOl = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // KbuttonGirisYap
            // 
            this.KbuttonGirisYap.Location = new System.Drawing.Point(374, 293);
            this.KbuttonGirisYap.Name = "KbuttonGirisYap";
            this.KbuttonGirisYap.Size = new System.Drawing.Size(161, 23);
            this.KbuttonGirisYap.TabIndex = 19;
            this.KbuttonGirisYap.Text = "GİRİŞ  YAP";
            this.KbuttonGirisYap.UseVisualStyleBackColor = true;
            this.KbuttonGirisYap.Click += new System.EventHandler(this.KbuttonGirisYap_Click);
            // 
            // KtextBoxSifre
            // 
            this.KtextBoxSifre.Location = new System.Drawing.Point(374, 250);
            this.KtextBoxSifre.Name = "KtextBoxSifre";
            this.KtextBoxSifre.Size = new System.Drawing.Size(161, 20);
            this.KtextBoxSifre.TabIndex = 18;
            // 
            // KtextBoxKAdi
            // 
            this.KtextBoxKAdi.Location = new System.Drawing.Point(374, 221);
            this.KtextBoxKAdi.Name = "KtextBoxKAdi";
            this.KtextBoxKAdi.Size = new System.Drawing.Size(161, 20);
            this.KtextBoxKAdi.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(266, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "ŞİFRE";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(266, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "KULLANICI ADI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(381, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "KULLANICI GİRİŞİ";
            // 
            // KbuttonKayıtOl
            // 
            this.KbuttonKayıtOl.Location = new System.Drawing.Point(374, 322);
            this.KbuttonKayıtOl.Name = "KbuttonKayıtOl";
            this.KbuttonKayıtOl.Size = new System.Drawing.Size(161, 23);
            this.KbuttonKayıtOl.TabIndex = 20;
            this.KbuttonKayıtOl.Text = "KAYIT OL";
            this.KbuttonKayıtOl.UseVisualStyleBackColor = true;
            this.KbuttonKayıtOl.Click += new System.EventHandler(this.KbuttonKayıtOl_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(115, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(594, 45);
            this.label1.TabIndex = 21;
            this.label1.Text = "MARKET OTOMASYONUNA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Elephant", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(241, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(346, 45);
            this.label2.TabIndex = 22;
            this.label2.Text = "HOŞGELDİNİZ";
            // 
            // GirisEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Market_Otomasyonu.Properties.Resources.WhatsApp_Image_2020_09_24_at_21_37_37;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.KbuttonKayıtOl);
            this.Controls.Add(this.KbuttonGirisYap);
            this.Controls.Add(this.KtextBoxSifre);
            this.Controls.Add(this.KtextBoxKAdi);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Name = "GirisEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giriş ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button KbuttonGirisYap;
        private System.Windows.Forms.TextBox KtextBoxSifre;
        private System.Windows.Forms.TextBox KtextBoxKAdi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button KbuttonKayıtOl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

